const estrategias = [
  {
    id: 1,
    nombre: "Horizonte Largo",
    autor: "Martina López",
    categoria_riesgo: "Bajo",
    precio: 29.99,
    rentabilidad_historica: 8.4,
    descripcion: "Estrategia basada en ETFs diversificados a nivel global con rebalanceo anual. Ideal para inversores conservadores que buscan crecimiento sostenido a largo plazo sin exposición a activos volátiles. Incluye posiciones en renta variable global, bonos de mercados desarrollados y una pequeña exposición a commodities."
  },
  {
    id: 2,
    nombre: "Momentum 360",
    autor: "Carlos Vega",
    categoria_riesgo: "Alto",
    precio: 89.99,
    rentabilidad_historica: 34.2,
    descripcion: "Estrategia de trading activo basada en análisis técnico y momentum de mercado. Opera en ventanas cortas aprovechando tendencias de alta volatilidad en acciones tech y cripto. Requiere monitoreo frecuente y tolerancia alta al riesgo. Historial de drawdowns significativos compensados por fuertes recuperaciones."
  },
  {
    id: 3,
    nombre: "Dividendos Plus",
    autor: "Ana Rodríguez",
    categoria_riesgo: "Bajo",
    precio: 49.99,
    rentabilidad_historica: 11.7,
    descripcion: "Cartera de acciones con historial sólido de pago de dividendos crecientes año a año. Foco en empresas maduras de sectores defensivos como utilities, salud y consumo básico. Genera flujo de caja estable con apreciación de capital moderada. Estrategia probada en entornos inflacionarios."
  },
  {
    id: 4,
    nombre: "LatAm Growth",
    autor: "Diego Herrera",
    categoria_riesgo: "Medio",
    precio: 64.99,
    rentabilidad_historica: 22.1,
    descripcion: "Estrategia enfocada en acciones de mercados emergentes latinoamericanos con alto potencial de crecimiento. Diversificada entre Brasil, México y Argentina con exposición selectiva a Chile y Colombia. Aprovecha ciclos de commodities y el crecimiento de la clase media regional."
  },
  {
    id: 5,
    nombre: "Cripto Core",
    autor: "Sofía Méndez",
    categoria_riesgo: "Alto",
    precio: 99.99,
    rentabilidad_historica: 51.3,
    descripcion: "Cartera activa de criptoactivos con rebalanceo mensual entre BTC, ETH y altcoins seleccionadas por fundamentales. Alta rentabilidad histórica acompañada de volatilidad significativa. Incluye gestión de riesgo con stop-loss dinámicos y distribución por capitalización de mercado."
  },
  {
    id: 6,
    nombre: "Bonos Seguros",
    autor: "Lucas Fernández",
    categoria_riesgo: "Bajo",
    precio: 19.99,
    rentabilidad_historica: 6.2,
    descripcion: "Estrategia 100% en renta fija. Incluye bonos soberanos y corporativos de alta calificación crediticia (investment grade). Mínimo riesgo, rendimiento estable y predecible. Ideal como núcleo defensivo de una cartera diversificada o como refugio en entornos de incertidumbre."
  }
];

let filtroActivo = 'Todos';
let searchQuery = '';

function initials(nombre) {
  return nombre.split(' ').slice(0, 2).map(n => n[0]).join('').toUpperCase();
}

function badgeClass(r) {
  if (r === 'Bajo') return 'badge-bajo';
  if (r === 'Medio') return 'badge-medio';
  return 'badge-alto';
}

function renderCards(data) {
  const grid = document.getElementById('cardGrid');
  const empty = document.getElementById('emptyState');
  const count = document.getElementById('resultsCount');

  count.textContent = `${data.length} resultado${data.length !== 1 ? 's' : ''}`;

  if (data.length === 0) {
    grid.innerHTML = '';
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';

  grid.innerHTML = data.map(e => `
    <article class="strat-card" onclick="openDetail(${e.id})" tabindex="0" role="button" aria-label="Ver detalle de ${e.nombre}">
      <div class="card-head">
        <span class="card-name">${e.nombre}</span>
        <span class="badge ${badgeClass(e.categoria_riesgo)}">${e.categoria_riesgo}</span>
      </div>
      <div class="card-author">
        <div class="avatar">${initials(e.autor)}</div>
        ${e.autor}
      </div>
      <p class="card-desc">${e.descripcion}</p>
      <div class="card-foot">
        <span class="card-price">USD ${e.precio.toFixed(2)}</span>
        <span class="card-rent">
          <svg width="14" height="14" viewBox="0 0 22 22" fill="none" aria-hidden="true">
            <polyline points="2,16 8,9 13,13 20,5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          ${e.rentabilidad_historica.toFixed(1)}% hist.
        </span>
      </div>
    </article>
  `).join('');

  grid.querySelectorAll('.strat-card').forEach(card => {
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') card.click(); });
  });
}

function applyFilters() {
  let data = [...estrategias];
  if (filtroActivo !== 'Todos') data = data.filter(e => e.categoria_riesgo === filtroActivo);
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    data = data.filter(e =>
      e.nombre.toLowerCase().includes(q) ||
      e.autor.toLowerCase().includes(q) ||
      e.descripcion.toLowerCase().includes(q)
    );
  }
  renderCards(data);
}

function openDetail(id) {
  const e = estrategias.find(x => x.id === id);
  const box = document.getElementById('detailBox');
  box.innerHTML = `
    <p class="detail-tag">ID #${String(e.id).padStart(4,'0')}</p>
    <h2 class="detail-title">${e.nombre}</h2>
    <div class="detail-author-row">
      <div class="avatar">${initials(e.autor)}</div>
      <span style="font-size:14px;color:#64748B">${e.autor}</span>
      <span class="badge ${badgeClass(e.categoria_riesgo)}" style="margin-left:4px">${e.categoria_riesgo}</span>
    </div>
    <div class="detail-metrics">
      <div class="metric">
        <div class="metric-label">Precio</div>
        <div class="metric-val">USD ${e.precio.toFixed(2)}</div>
      </div>
      <div class="metric">
        <div class="metric-label">Rentabilidad histórica</div>
        <div class="metric-val green">${e.rentabilidad_historica.toFixed(1)}%</div>
      </div>
      <div class="metric">
        <div class="metric-label">Categoría de riesgo</div>
        <div class="metric-val" style="font-size:16px">${e.categoria_riesgo}</div>
      </div>
      <div class="metric">
        <div class="metric-label">Publicado por</div>
        <div class="metric-val" style="font-size:15px;font-weight:500">${e.autor.split(' ')[0]}</div>
      </div>
    </div>
    <div class="detail-divider"></div>
    <p class="detail-desc-label">Descripción</p>
    <p class="detail-desc">${e.descripcion}</p>
    <div class="detail-actions">
      <button class="btn-secondary" onclick="closeModal('detail')">Volver</button>
      <button class="btn-primary" onclick="handleAcceder('${e.nombre}')">Acceder a esta estrategia</button>
    </div>
  `;
  document.getElementById('detailModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function handleAcceder(nombre) {
  closeModal('detail');
  showToast(`✓ Acceso a "${nombre}" confirmado`);
}

function openModal(type) {
  if (type === 'publish') {
    document.getElementById('publishModal').classList.add('open');
  }
  document.body.style.overflow = 'hidden';
}

function closeModal(type) {
  if (type === 'detail') document.getElementById('detailModal').classList.remove('open');
  if (type === 'publish') document.getElementById('publishModal').classList.remove('open');
  document.body.style.overflow = '';
}

function publishStrategy() {
  const nombre = document.getElementById('pubNombre').value.trim();
  const autor = document.getElementById('pubAutor').value.trim();
  const riesgo = document.getElementById('pubRiesgo').value;
  const precio = parseFloat(document.getElementById('pubPrecio').value);
  const rent = parseFloat(document.getElementById('pubRent').value);
  const desc = document.getElementById('pubDesc').value.trim();

  if (!nombre || !autor || !desc || isNaN(precio) || isNaN(rent)) {
    showToast('⚠ Completá todos los campos');
    return;
  }

  const nueva = {
    id: estrategias.length + 1,
    nombre,
    autor,
    categoria_riesgo: riesgo,
    precio: parseFloat(precio.toFixed(2)),
    rentabilidad_historica: parseFloat(rent.toFixed(1)),
    descripcion: desc
  };

  estrategias.unshift(nueva);
  closeModal('publish');
  document.getElementById('pubNombre').value = '';
  document.getElementById('pubAutor').value = '';
  document.getElementById('pubPrecio').value = '';
  document.getElementById('pubRent').value = '';
  document.getElementById('pubDesc').value = '';

  filtroActivo = 'Todos';
  document.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c.dataset.filter === 'Todos'));
  searchQuery = '';
  document.getElementById('searchInput').value = '';

  applyFilters();
  document.getElementById('statTotal').textContent = estrategias.length;
  showToast(`✓ "${nombre}" publicada exitosamente`);
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2800);
}

document.getElementById('searchInput').addEventListener('input', e => {
  searchQuery = e.target.value;
  applyFilters();
});

document.getElementById('chips').addEventListener('click', e => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  filtroActivo = chip.dataset.filter;
  document.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c === chip));
  applyFilters();
});

document.getElementById('detailModal').addEventListener('click', e => {
  if (e.target === document.getElementById('detailModal')) closeModal('detail');
});
document.getElementById('publishModal').addEventListener('click', e => {
  if (e.target === document.getElementById('publishModal')) closeModal('publish');
});

document.getElementById('hamburger').addEventListener('click', () => {
  document.getElementById('mobileMenu').classList.toggle('open');
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeModal('detail'); closeModal('publish'); }
});

applyFilters();
